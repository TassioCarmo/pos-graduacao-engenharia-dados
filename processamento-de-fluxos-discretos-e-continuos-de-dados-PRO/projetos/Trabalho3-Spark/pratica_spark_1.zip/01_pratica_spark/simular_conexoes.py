import requests
import random
import json

def get_user_ids():
    response = requests.get("http://localhost:8000/re/v2/users/bulk")
    if response.status_code != 200:
        print(f"Erro ao obter os usuários: {response.json()}")
        return
    else:
        print(f"Resultado da requisição({response.status_code}): ", response.json())
        return [int(user_id) for user_id in response.json()["user_ids"]]

def simular_conexoes_50_users(all_user_ids):
    if all_user_ids is None:
        return
    
    for i in range(0, 50):
        user_id = random.choice(all_user_ids)
        response = requests.get(f"http://localhost:8000/re/v2/users/id/{user_id}")
        print(f"Requisição {i} enviada para o usuário {user_id}, status: {response.status_code}, resultado: {response.json()}")

def simular_conexoes_10_users_by_list_endpoint(all_user_ids):
    if all_user_ids is None:
        return

    for i in range(0, 2):
        user_ids = random.sample(all_user_ids, 10)
        user_response = requests.post(f"http://localhost:8000/re/v2/users/ids", json={"user_ids": user_ids})
        if user_response.status_code != 200:
            print(f"Erro ao enviar a requisição {i}: {user_response.json()}")
            return
        print(f"Resultado da requisição {i} ({user_response.status_code}): ", user_response.json())

def simular_endpoint_lista_recomendacoes_random():
    number_of_users = random.randint(1, 50)
    response = requests.get(f"http://localhost:8000/re/v2/users/recommendations/random/{number_of_users}")
    if response.status_code != 200:
        print(f"Erro ao enviar a requisição: {response.json()}")
        return
    print(f"Resultado da requisição ({response.status_code}): ", response.json())

if __name__ == "__main__":
    print("======== Consulta total de usuários")
    all_user_ids = get_user_ids()
    if all_user_ids is None:
        print("Não foi possível obter os usuários")
        exit(1)

    print("======== Simulando conexões com 50 conexões uma por usuário")
    simular_conexoes_50_users(all_user_ids)
    print("======== Simulando conexões com 10 usuários por endpoint")
    simular_conexoes_10_users_by_list_endpoint(all_user_ids)
    print("======== Simulando conexões endpoint de recomendações random")
    simular_endpoint_lista_recomendacoes_random()
