from pymongo import MongoClient
from dotenv import load_dotenv
import os
from pymongo.collection import Collection


load_dotenv()  # Load .env file at the start

def inicia_conexao_mongo() -> Collection:
    ## Inicializa a conexão com o MongoDB
    mongo_host = os.getenv("MONGO_HOST")
    mongo_port = os.getenv("MONGO_PORT")
    client = MongoClient(mongo_host, int(mongo_port))
    
    ## Inicializa a conexão com o banco de dados
    mongo_db = os.getenv("MONGO_DB")
    db = client[mongo_db]
    
    ## Inicializa a conexão com a coleção
    mongo_collection = os.getenv("MONGO_COLLECTION")    
    collection = db[mongo_collection]
    
    ## Retorna a coleção
    return collection

def clean_collection(collection: Collection) -> None:
    collection.delete_many({})


def get_ratings_by_user_id(user_id: int, collection: Collection) -> list:
    """
    Retorna as recomendações de filmes de um usuário
    """
    recomendacoes = list(collection.find({"userId": user_id}))
    list_rec = []
    for rec in recomendacoes:
        list_rec.append((rec["movieId"], rec["rating"]))
    return {"filmes": list_rec[0][0], "notas_estimadas": list_rec[0][1]}


def get_ratings_by_user_ids(user_ids: list[int], collection: Collection) -> list:
    """
    Retorna as recomendações de filmes de uma lista de usuários
    """
    recomendacoes = list(collection.find({"userId": {"$in": user_ids}}))
    dict_user_id_rec = {}
    for rec in recomendacoes:
        dict_user_id_rec[rec["userId"]] = (rec["movieId"], rec["rating"])
    return dict_user_id_rec


def get_user_ids(collection: Collection) -> list:
    """
    Retorna os ids dos usuários
    """
    recomendacoes = list(collection.find())
    list_rec = []
    for rec in recomendacoes:
        list_rec.append(rec["userId"])
    return list_rec

# if __name__ == "__main__":
#     collection = inicia_conexao_mongo()
#     # user_id = 10
#     # print(f"Recomendações do usuário {user_id}: {get_ratings_by_user_id(user_id, collection)}")
#     print(f"Ids dos usuários: {get_user_ids(collection)}")
