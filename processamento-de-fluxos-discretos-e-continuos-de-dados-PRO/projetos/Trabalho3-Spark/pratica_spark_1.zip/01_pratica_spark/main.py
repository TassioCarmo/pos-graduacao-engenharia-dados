import fastapi
import uvicorn
import db.mongo as mongo
import random
from fastapi import Request

app = fastapi.FastAPI()
collection = mongo.inicia_conexao_mongo()

@app.get("/re/v1")
def read_root():
    return {"Rota padrão": "Você acessou o endpoint padrão"}

@app.get("/re/v2/users/bulk")
def get_user_ids():
    result = mongo.get_user_ids(collection)
    return {"user_ids": result}

@app.get("/re/v2/users/recommendations/random/{number_of_users}")
def get_recommendations_random(number_of_users: int):
    all_user_ids = list(sorted(mongo.get_user_ids(collection)))
    result = []
    for i in range(0, number_of_users):
        user_id = random.choice(all_user_ids)
        result.append(mongo.get_ratings_by_user_id(user_id, collection))
    return {"number_of_users": number_of_users, "resultado_recomendacoes": result}

@app.get("/re/v2/users/id/{user_id}")
def get_recomendacoes(user_id: int):
    return {"user_id": user_id, "resultado_recomendacoes": mongo.get_ratings_by_user_id(user_id, collection)}

@app.post("/re/v2/users/ids")
async def get_recomendacoes(request: Request):
    request_json = await request.json()
    user_ids = request_json["user_ids"]
    return {"user_ids": user_ids, "resultado_recomendacoes": mongo.get_ratings_by_user_ids(user_ids, collection)}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
